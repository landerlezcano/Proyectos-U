package Control;
import Modelo.Empresa;
import Vista.InOut;
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Yair Lopez Poveda
 */
public class Ejecutar {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Empresa ob1 = new Empresa();
        ob1.ejecutarMenu();
    }
}
